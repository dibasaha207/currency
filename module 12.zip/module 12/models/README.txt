MODEL WEIGHTS DIRECTORY
======================

Place your trained YOLOv11 model weights (best.pt) from Phase-1 in this directory.

Expected file: models/best.pt

To set up the model, copy your trained model from Phase-1:

Windows:
  copy "runs\detect\currency detection\weights\best.pt" models\best.pt

Linux/Mac:
  cp "runs/detect/currency detection/weights/best.pt" models/best.pt
